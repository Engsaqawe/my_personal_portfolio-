"""Create tables and seed ENGSAQAWE MySQL database."""

from database import get_db
from auth import hash_password, DEFAULT_ADMIN_USER, DEFAULT_ADMIN_PASS
from site_settings import SETTINGS_SCHEMA

SCHEMA = """
CREATE TABLE IF NOT EXISTS contacts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(180) NOT NULL,
    project_type VARCHAR(80) DEFAULT NULL,
    message TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(160) NOT NULL,
    description TEXT NOT NULL,
    features TEXT,
    challenges TEXT,
    solutions TEXT,
    tech_stack VARCHAR(255) NOT NULL,
    category VARCHAR(80) NOT NULL,
    image_url VARCHAR(255) DEFAULT NULL,
    live_link VARCHAR(255) DEFAULT NULL,
    source_link VARCHAR(255) DEFAULT NULL,
    sort_order INT DEFAULT 0,
    featured TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS certificates (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(160) NOT NULL,
    issuer VARCHAR(160) NOT NULL,
    year VARCHAR(10) NOT NULL,
    description TEXT,
    image_url VARCHAR(255) NOT NULL,
    preview_url VARCHAR(255) DEFAULT NULL,
    download_url VARCHAR(255) DEFAULT NULL,
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(160) NOT NULL,
    description TEXT NOT NULL,
    modules VARCHAR(80) NOT NULL,
    progress INT DEFAULT 0,
    icon VARCHAR(60) DEFAULT 'fa-code',
    sort_order INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS academy_students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    email VARCHAR(180) NOT NULL,
    course_id INT DEFAULT NULL,
    status VARCHAR(40) DEFAULT 'active',
    progress INT DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (course_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS profile (
    id INT PRIMARY KEY DEFAULT 1,
    full_name VARCHAR(120) NOT NULL,
    brand_name VARCHAR(80) NOT NULL,
    tagline VARCHAR(180) NOT NULL,
    hero_title VARCHAR(255) NOT NULL,
    hero_subtitle TEXT NOT NULL,
    mission TEXT NOT NULL,
    vision TEXT NOT NULL,
    location_note VARCHAR(180) DEFAULT NULL,
    email VARCHAR(180) NOT NULL,
    whatsapp VARCHAR(40) DEFAULT NULL,
    github_url VARCHAR(255) DEFAULT NULL,
    linkedin_url VARCHAR(255) DEFAULT NULL,
    twitter_url VARCHAR(255) DEFAULT NULL,
    facebook_url VARCHAR(255) DEFAULT NULL,
    youtube_url VARCHAR(255) DEFAULT NULL,
    hero_image VARCHAR(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(120) DEFAULT NULL,
    email VARCHAR(180) DEFAULT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS gallery (
    id INT AUTO_INCREMENT PRIMARY KEY,
    label VARCHAR(120) DEFAULT NULL,
    image_url VARCHAR(255) NOT NULL,
    sort_order INT DEFAULT 0,
    is_hero TINYINT(1) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS site_settings (
    setting_key VARCHAR(100) PRIMARY KEY,
    setting_value TEXT,
    setting_group VARCHAR(60) DEFAULT 'general',
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    slug VARCHAR(220) NOT NULL UNIQUE,
    excerpt VARCHAR(500) DEFAULT NULL,
    body MEDIUMTEXT NOT NULL,
    cover_image VARCHAR(255) DEFAULT NULL,
    category VARCHAR(100) DEFAULT NULL,
    tags VARCHAR(255) DEFAULT NULL,
    author VARCHAR(120) DEFAULT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'draft',
    seo_title VARCHAR(200) DEFAULT NULL,
    seo_description VARCHAR(320) DEFAULT NULL,
    published_at DATETIME DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (status, published_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_post_views (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    visitor_key CHAR(64) NOT NULL,
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY unique_post_visitor (post_id, visitor_key),
    CONSTRAINT fk_blog_view_post FOREIGN KEY (post_id) REFERENCES blog_posts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_post_reactions (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    visitor_key CHAR(64) NOT NULL,
    reaction VARCHAR(12) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_post_reaction (post_id, visitor_key),
    CONSTRAINT fk_blog_reaction_post FOREIGN KEY (post_id) REFERENCES blog_posts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS blog_comments (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    post_id INT NOT NULL,
    name VARCHAR(80) NOT NULL,
    body VARCHAR(1200) NOT NULL,
    status VARCHAR(16) NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX blog_comments_status (status, created_at),
    CONSTRAINT fk_blog_comment_post FOREIGN KEY (post_id) REFERENCES blog_posts(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS footer_links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    section_title VARCHAR(100) NOT NULL,
    label VARCHAR(120) NOT NULL,
    url VARCHAR(500) NOT NULL,
    image_url VARCHAR(500) DEFAULT NULL,
    sort_order INT DEFAULT 0,
    section_order INT DEFAULT 0,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
"""

PROJECTS = [
    (
        "EcoTrack SaaS",
        "Environmental impact tracking platform for enterprise teams — dashboards, reporting, and compliance in one calm interface.",
        "Real-time analytics|Role-based dashboards|Exportable compliance reports|Dark-first UI system",
        "Complex data density without overwhelming operators.",
        "Modular card system, progressive disclosure, and motion that guides attention to anomalies only.",
        "Python,Flask,MySQL,JavaScript,GSAP",
        "saas",
        "images/pictures/3.png",
        "https://ecotrack.engsaqawe.app",
        "https://github.com/engsaqawe/ecotrack",
        1,
    ),
    (
        "Academy LMS",
        "Learning management system with progress tracking, course modules, and a premium student experience.",
        "Course progress bars|Video-ready modules|Student analytics|Responsive layouts",
        "Balancing educational clarity with a premium brand feel.",
        "Typography-led hierarchy, glass cards, and scroll-driven reveals for each module.",
        "Python,Flask,MySQL,HTML5,CSS3",
        "enterprise",
        "images/pictures/4.png",
        "https://academy.engsaqawe.app",
        "https://github.com/engsaqawe/academy-lms",
        2,
    ),
    (
        "NexGen Portfolio",
        "High-performance developer portfolio focused on Core Web Vitals, motion, and accessibility.",
        "95+ Lighthouse targets|Lenis smooth scroll|GSAP scenes|Semantic HTML",
        "Heavy animation without sacrificing performance.",
        "Reduced-motion paths, lazy media, and GPU-friendly transforms only.",
        "HTML5,CSS3,JavaScript,GSAP,Lenis",
        "experiments",
        "images/pictures/5.png",
        "https://portfolio.engsaqawe.app",
        "https://github.com/engsaqawe/portfolio",
        3,
    ),
    (
        "SecurePay API",
        "Payment gateway integration with encryption, webhooks, and operator-friendly monitoring.",
        "Webhook reliability|Encrypted payloads|Audit logs|Operator console",
        "High-stakes flows must feel calm under pressure.",
        "Status-first UI, keyboard workflows, and clear error recovery patterns.",
        "Python,Flask,MySQL,Redis,Docker",
        "enterprise",
        "images/pictures/2.png",
        "https://securepay.engsaqawe.app",
        "https://github.com/engsaqawe/securepay",
        4,
    ),
]

CERTIFICATES = [
    (
        "Certificate of Achievement",
        "Weblake Corp",
        "2025",
        "Recognized for exceptional effort, dedication, and accomplishment in professional development.",
        "images/pictures/certi1.jpg",
        "https://new.express.adobe.com/id/urn:aaid:sc:EU:3b5bf125-d435-5612-a1fb-934599f172d3",
        "images/pictures/certi1.jpg",
        1,
    ),
    (
        "Advanced Frontend Architecture",
        "International Tech Institute",
        "2025",
        "Scalable front-end architecture, design systems, performance, and accessibility for modern web apps.",
        "images/pictures/certi1.jpg",
        None,
        "images/pictures/certi1.jpg",
        2,
    ),
    (
        "Cloud-Native Systems",
        "Cloud Engineering Institute",
        "2024",
        "Distributed systems, reliability engineering, observability, and deployment strategies.",
        "images/pictures/certi1.jpg",
        None,
        "images/pictures/certi1.jpg",
        3,
    ),
]

COURSES = [
    (
        "Interface Systems Lab",
        "Build a production-ready design system from tokens to motion using native web technologies.",
        "6 modules",
        72,
        "fa-bezier-curve",
        1,
    ),
    (
        "Performance By Design",
        "Design and engineer for Lighthouse 95+ without sacrificing visuals, motion, or ambition.",
        "4 modules",
        54,
        "fa-gauge-high",
        2,
    ),
    (
        "Motion for Product Teams",
        "Practical motion design in product interfaces — principles to implementation in CSS and JS.",
        "5 modules",
        38,
        "fa-wave-square",
        3,
    ),
]

PROFILE = (
    "Nor Ali Saqawe",
    "ENGSAQAWE",
    "Developer · Builder · Educator",
    "Engineering quiet breakthroughs for loud results.",
    "I craft scalable systems, premium web applications, and digital experiences that feel effortless on the surface and powerful underneath.",
    "To build software that feels inevitable — interfaces and systems so considered they get out of the way and let teams do their best work.",
    "A world where ambitious ideas are not constrained by tooling. ENGSAQAWE turns complex requirements into precise, calm, scalable digital products.",
    "Remote-friendly · Available worldwide",
    "hello@engsaqawe.com",
    "684421687",
    "https://github.com",
    "https://www.linkedin.com",
    "https://x.com",
)


def run_sql(conn, sql):
    with conn.cursor() as cur:
        for statement in sql.strip().split(";"):
            stmt = statement.strip()
            if stmt:
                cur.execute(stmt)
    conn.commit()


GALLERY = [
    ("Hero portrait", "images/pictures/me.png", 1, 1),
    ("Portrait 2", "images/pictures/me2.png", 2, 0),
    ("Portrait 3", "images/pictures/me3.png", 3, 0),
    ("Portrait 4", "images/pictures/me4.png", 4, 0),
    ("Portrait 5", "images/pictures/5.png", 5, 0),
]


def migrate_profile_columns(conn):
    columns = [
        ("facebook_url", "VARCHAR(255) DEFAULT NULL"),
        ("youtube_url", "VARCHAR(255) DEFAULT NULL"),
        ("hero_image", "VARCHAR(255) DEFAULT NULL"),
    ]
    with conn.cursor() as cur:
        for name, definition in columns:
            try:
                cur.execute(f"ALTER TABLE profile ADD COLUMN {name} {definition}")
            except Exception:
                pass
    conn.commit()


def seed():
    conn = get_db()
    try:
        run_sql(conn, SCHEMA)
        migrate_profile_columns(conn)

        with conn.cursor() as cur:
            cur.execute("SHOW COLUMNS FROM footer_links LIKE 'image_url'")
            if not cur.fetchone():
                cur.execute("ALTER TABLE footer_links ADD COLUMN image_url VARCHAR(500) DEFAULT NULL AFTER url")

            cur.execute("SELECT COUNT(*) AS c FROM projects")
            if cur.fetchone()["c"] == 0:
                cur.executemany(
                    """INSERT INTO projects
                    (title, description, features, challenges, solutions, tech_stack, category, image_url, live_link, source_link, sort_order)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    PROJECTS,
                )

            cur.execute("SELECT COUNT(*) AS c FROM certificates")
            if cur.fetchone()["c"] == 0:
                cur.executemany(
                    """INSERT INTO certificates
                    (title, issuer, year, description, image_url, preview_url, download_url, sort_order)
                    VALUES (%s,%s,%s,%s,%s,%s,%s,%s)""",
                    CERTIFICATES,
                )

            cur.execute("SELECT COUNT(*) AS c FROM courses")
            if cur.fetchone()["c"] == 0:
                cur.executemany(
                    """INSERT INTO courses (title, description, modules, progress, icon, sort_order)
                    VALUES (%s,%s,%s,%s,%s,%s)""",
                    COURSES,
                )

            cur.execute("SELECT COUNT(*) AS c FROM profile")
            if cur.fetchone()["c"] == 0:
                cur.execute(
                    """INSERT INTO profile
                    (id, full_name, brand_name, tagline, hero_title, hero_subtitle, mission, vision,
                     location_note, email, whatsapp, github_url, linkedin_url, twitter_url)
                    VALUES (1,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)""",
                    PROFILE,
                )

            cur.execute("SELECT COUNT(*) AS c FROM admins")
            if cur.fetchone()["c"] == 0:
                if not DEFAULT_ADMIN_USER or not DEFAULT_ADMIN_PASS:
                    raise RuntimeError("Set ADMIN_USERNAME and ADMIN_PASSWORD before creating the first administrator.")
                cur.execute(
                    """INSERT INTO admins (username, password_hash, full_name, email)
                       VALUES (%s, %s, %s, %s)""",
                    (DEFAULT_ADMIN_USER, hash_password(DEFAULT_ADMIN_PASS), "Nor Ali Saqawe", "hello@engsaqawe.com"),
                )

            cur.execute("SELECT COUNT(*) AS c FROM gallery")
            if cur.fetchone()["c"] == 0:
                cur.executemany(
                    """INSERT INTO gallery (label, image_url, sort_order, is_hero)
                       VALUES (%s, %s, %s, %s)""",
                    GALLERY,
                )

            cur.execute("SELECT COUNT(*) AS c FROM footer_links WHERE LOWER(section_title) = 'affiliate links'")
            if cur.fetchone()["c"] == 0:
                cur.execute(
                    """INSERT INTO footer_links (section_title, label, url, sort_order, section_order, is_active)
                       VALUES ('Affiliate links', %s, %s, 0, 0, 1)""",
                    ("Namecheap Hosting", "https://www.namecheap.com/hosting/"),
                )

            # Seed any missing site_settings keys (never overwrite existing)
            for key, group, _label, default, _itype in SETTINGS_SCHEMA:
                cur.execute("SELECT setting_key FROM site_settings WHERE setting_key = %s", (key,))
                if not cur.fetchone():
                    cur.execute(
                        """INSERT INTO site_settings (setting_key, setting_value, setting_group)
                           VALUES (%s, %s, %s)""",
                        (key, default, group),
                    )

            # Prefer built-in Academy Panel over old external default
            cur.execute(
                """UPDATE site_settings SET setting_value=%s
                   WHERE setting_key='academy_external_url'
                   AND (setting_value=%s OR setting_value=%s)""",
                ("", "https://academy.engsaqawe.app", "https://academy.engsaqawe.app/"),
            )

        conn.commit()
        print("MySQL schema ready and seeded.")
    finally:
        conn.close()


def update_demo_links():
    """Update live demo URLs on existing projects."""
    demos = {
        "EcoTrack SaaS": "https://ecotrack.engsaqawe.app",
        "Academy LMS": "https://academy.engsaqawe.app",
        "NexGen Portfolio": "https://portfolio.engsaqawe.app",
        "SecurePay API": "https://securepay.engsaqawe.app",
    }
    conn = get_db()
    try:
        with conn.cursor() as cur:
            for title, url in demos.items():
                cur.execute("UPDATE projects SET live_link = %s WHERE title = %s", (url, title))
        conn.commit()
        print("Demo links updated.")
    finally:
        conn.close()


def update_whatsapp():
    """Ensure profile WhatsApp matches site default."""
    conn = get_db()
    try:
        with conn.cursor() as cur:
            cur.execute("UPDATE profile SET whatsapp = %s WHERE id = 1", ("684421687",))
        conn.commit()
        print("WhatsApp number updated.")
    finally:
        conn.close()


if __name__ == "__main__":
    seed()
    update_demo_links()
    update_whatsapp()
