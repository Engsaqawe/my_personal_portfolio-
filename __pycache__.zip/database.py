"""MySQL connection helpers for ENGSAQAWE."""

import os
import pymysql
from pymysql.cursors import DictCursor

DB_CONFIG = {
    "host": os.getenv("DB_HOST", "localhost"),
    "port": int(os.getenv("DB_PORT", "3306")),
    "user": os.getenv("DB_USER", "Engsaqawe"),
    "password": os.getenv("DB_PASSWORD", ""),
    "database": os.getenv("DB_NAME", "Engsaqawe"),
    "charset": "utf8mb4",
    "cursorclass": DictCursor,
    "autocommit": False,
}


def get_db():
    if os.getenv("APP_ENV", "development").strip().lower() == "production" and not DB_CONFIG["password"]:
        raise RuntimeError("DB_PASSWORD must be set in production.")
    return pymysql.connect(**DB_CONFIG)
