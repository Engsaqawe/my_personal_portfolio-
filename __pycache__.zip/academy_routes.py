"""ENGSAQAWE Academy management panel — admin-style UI for courses & students."""

from flask import Blueprint, render_template, request, redirect, url_for, flash, session
from auth import admin_required, login_admin
from db_helpers import query_all, query_one, execute, execute_returning_id

academy_bp = Blueprint("academy", __name__, url_prefix="/academy")


@academy_bp.route("/login", methods=["GET", "POST"])
def login():
    nxt = request.args.get("next") or request.form.get("next") or ""
    if nxt and not nxt.startswith("/academy"):
        nxt = ""

    if session.get("admin_id"):
        return redirect(nxt or url_for("academy.dashboard"))

    if request.method == "POST":
        username = (request.form.get("username") or "").strip()
        password = request.form.get("password") or ""
        admin = login_admin(username, password)
        if admin:
            session.clear()
            session["admin_id"] = admin["id"]
            session["admin_username"] = admin["username"]
            flash("Welcome to Academy Panel.", "success")
            return redirect(nxt or url_for("academy.dashboard"))
        flash("Wrong username or password.", "error")

    return render_template("academy/login.html", next=nxt)


@academy_bp.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("Logged out of Academy Panel.", "success")
    return redirect(url_for("academy.login"))


@academy_bp.route("/")
@admin_required
def dashboard():
    stats = {
        "courses": query_one("SELECT COUNT(*) AS c FROM courses")["c"],
        "students": query_one("SELECT COUNT(*) AS c FROM academy_students")["c"],
        "active": query_one("SELECT COUNT(*) AS c FROM academy_students WHERE status = 'active'")["c"],
        "avg_progress": query_one("SELECT COALESCE(AVG(progress), 0) AS a FROM courses")["a"],
    }
    courses = query_all("SELECT * FROM courses ORDER BY sort_order ASC, id ASC LIMIT 6")
    recent = query_all(
        """SELECT s.*, c.title AS course_title
           FROM academy_students s
           LEFT JOIN courses c ON c.id = s.course_id
           ORDER BY s.id DESC LIMIT 5"""
    )
    admin = query_one(
        "SELECT id, username, full_name FROM admins WHERE id = %s",
        (session["admin_id"],),
    )
    return render_template(
        "academy/dashboard.html",
        stats=stats,
        courses=courses,
        recent=recent,
        admin=admin,
    )


@academy_bp.route("/courses")
@admin_required
def courses_list():
    courses = query_all("SELECT * FROM courses ORDER BY sort_order ASC, id ASC")
    return render_template("academy/courses_list.html", courses=courses)


@academy_bp.route("/courses/new", methods=["GET", "POST"])
@academy_bp.route("/courses/<int:item_id>/edit", methods=["GET", "POST"])
@admin_required
def course_form(item_id=None):
    course = query_one("SELECT * FROM courses WHERE id = %s", (item_id,)) if item_id else None

    if request.method == "POST":
        title = (request.form.get("title") or "").strip()
        description = (request.form.get("description") or "").strip()
        modules = (request.form.get("modules") or "").strip()
        icon = (request.form.get("icon") or "fa-code").strip()
        try:
            progress = int(request.form.get("progress") or 0)
        except ValueError:
            progress = 0
        try:
            sort_order = int(request.form.get("sort_order") or 0)
        except ValueError:
            sort_order = 0
        progress = max(0, min(100, progress))

        if not title or not description:
            flash("Title and description are required.", "error")
            return render_template("academy/course_form.html", course=course)

        if course:
            execute(
                """UPDATE courses SET title=%s, description=%s, modules=%s,
                   progress=%s, icon=%s, sort_order=%s WHERE id=%s""",
                (title, description, modules, progress, icon, sort_order, item_id),
            )
            flash("Course updated.", "success")
        else:
            execute(
                """INSERT INTO courses (title, description, modules, progress, icon, sort_order)
                   VALUES (%s,%s,%s,%s,%s,%s)""",
                (title, description, modules, progress, icon, sort_order),
            )
            flash("Course created.", "success")
        return redirect(url_for("academy.courses_list"))

    return render_template("academy/course_form.html", course=course)


@academy_bp.route("/courses/<int:item_id>/delete", methods=["POST"])
@admin_required
def course_delete(item_id):
    execute("DELETE FROM academy_students WHERE course_id = %s", (item_id,))
    execute("DELETE FROM courses WHERE id = %s", (item_id,))
    flash("Course deleted.", "success")
    return redirect(url_for("academy.courses_list"))


@academy_bp.route("/students")
@admin_required
def students_list():
    students = query_all(
        """SELECT s.*, c.title AS course_title
           FROM academy_students s
           LEFT JOIN courses c ON c.id = s.course_id
           ORDER BY s.id DESC"""
    )
    return render_template("academy/students_list.html", students=students)


@academy_bp.route("/students/new", methods=["GET", "POST"])
@academy_bp.route("/students/<int:item_id>/edit", methods=["GET", "POST"])
@admin_required
def student_form(item_id=None):
    student = query_one("SELECT * FROM academy_students WHERE id = %s", (item_id,)) if item_id else None
    courses = query_all("SELECT id, title FROM courses ORDER BY sort_order ASC, id ASC")

    if request.method == "POST":
        name = (request.form.get("name") or "").strip()
        email = (request.form.get("email") or "").strip()
        status = (request.form.get("status") or "active").strip()
        notes = (request.form.get("notes") or "").strip()
        course_id = request.form.get("course_id") or None
        try:
            progress = int(request.form.get("progress") or 0)
        except ValueError:
            progress = 0
        progress = max(0, min(100, progress))
        if course_id:
            try:
                course_id = int(course_id)
            except ValueError:
                course_id = None

        if not name or not email:
            flash("Name and email are required.", "error")
            return render_template("academy/student_form.html", student=student, courses=courses)

        if student:
            execute(
                """UPDATE academy_students SET name=%s, email=%s, course_id=%s,
                   status=%s, progress=%s, notes=%s WHERE id=%s""",
                (name, email, course_id, status, progress, notes, item_id),
            )
            flash("Student updated.", "success")
        else:
            execute(
                """INSERT INTO academy_students (name, email, course_id, status, progress, notes)
                   VALUES (%s,%s,%s,%s,%s,%s)""",
                (name, email, course_id, status, progress, notes),
            )
            flash("Student enrolled.", "success")
        return redirect(url_for("academy.students_list"))

    return render_template("academy/student_form.html", student=student, courses=courses)


@academy_bp.route("/students/<int:item_id>/delete", methods=["POST"])
@admin_required
def student_delete(item_id):
    execute("DELETE FROM academy_students WHERE id = %s", (item_id,))
    flash("Student removed.", "success")
    return redirect(url_for("academy.students_list"))
